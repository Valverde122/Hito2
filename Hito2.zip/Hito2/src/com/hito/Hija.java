package com.hito;

public class Hija extends Padre {
	
public String saludar() {
		
		return "Hola soy la hija";
		}

	
	
}
