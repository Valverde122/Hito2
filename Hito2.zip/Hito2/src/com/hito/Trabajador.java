package com.hito;

public class Trabajador {
	//Atributos
	
	private String nombre,ciudad;
	private float salarioBruto;
	boolean contratoTemporal;
	
	public Trabajador(String nombre, String ciudad, float salarioBruto, boolean contratoTemporal) {
		super();
		this.nombre = nombre;
		this.ciudad = ciudad;
		this.salarioBruto = salarioBruto;
		this.contratoTemporal = contratoTemporal;
		
		//getters y setters
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getCiudad() {
		return ciudad;
	}

	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}

	public float getSalarioBruto() {
		return salarioBruto;
	}

	public void setSalarioBruto(float salarioBruto) {
		this.salarioBruto = salarioBruto;
	}

	public boolean isContratoTemporal() {
		return contratoTemporal;
	}

	public void setContratoTemporal(boolean contratoTemporal) {
		this.contratoTemporal = contratoTemporal;
	}
	
	//metodos genericos
	public String trabajador() {
		
	return "Trabjador [nombre=" + nombre + ", salarioBruto" + salarioBruto + ",contratoTemporal" + contratoTemporal +"]";
	}
	
	
	
	
	
	
}
