package com.hito;

public class Ejecutar {
	
	public static void main(String[] args) {
		
		Trabajador trabajador=new Trabajador("Pedro", "Sevilla", 3000f, true);
		System.out.println(trabajador);
		
		Hija hija=new Hija();
		String saludar=hija.saludar();
		System.out.println(saludar);
		
		
		
		
		
		
	}

}
