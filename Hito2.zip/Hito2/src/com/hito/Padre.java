package com.hito;


//con abstract consigo que no pueda ser instanciada
public abstract class  Padre {
	
	//dato texto y numerico
	public String texto;
	public int numero;
	
	
	
	
	public String getTexto() {
		return texto;
	}




	public void setTexto(String texto) {
		this.texto = texto;
	}




	public int getNumero() {
		return numero;
	}




	public void setNumero(int numero) {
		this.numero = numero;
	}




	//constructor y mensaje de vuelta
	public String saludo() {
		
		return "Hola soy el Padre";
		}
	
	

}
