package com.base;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Alumno alumno1 = new Alumno("Pedro", 25);
		Profesor profesor1 = new Profesor("Mario", 26);
		
		
		/*En este caso he hecho un ejemplo en el que dando unos valores se guardan y despues salen por pantalla*/
		
		Persona[] colegio= {alumno1,profesor1};
		int i= 0;
		for(i=0; i<=1;i++) {
			colegio[i].datos();
		}
		
		

}
}



