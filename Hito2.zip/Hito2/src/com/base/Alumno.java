package com.base;

public class Alumno extends Persona {
	
	public Alumno(String nombre, int edad) {
		super(nombre, edad);
		
	}
	
	
	public void datos() {
		
		System.out.println("Mi nombre es   "  +getNombre()  +"mi edad es  "+getEdad()  +"y mi profesor es ");
		
	}

}


