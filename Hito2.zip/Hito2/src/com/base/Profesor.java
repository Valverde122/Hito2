package com.base;

public class Profesor extends Persona {
	
	public Profesor(String nombre, int edad) {
		super(nombre, edad);}
		
		public void datos() {
			
			System.out.println("Mi nombre es "  +getNombre() +"mi edad es "+getEdad()  +"y mi nombre es ");
			
		}
	

}

